﻿<###########################################################

    Author = Samba NDIAYE
    Description = Automatisation de l'arret/relance des bases de données
    

############################################################>

#Parametres


$action
$database
$type="MSSQL"
$server


#le fichier de log lors de chaque execution
$LOG = ".\log.txt"
$DATABASE_SCRIPT_PATH = "S:\MSSQL.SCRIPTS\bin\BDDSQLServer.ps1" 

$LOG_FILE = "database.log"
$PSEXEC = '.\PsExec.exe'
$BAT_Psexec = 'script_invoker.bat'
$console = $false
#
#Test la connection avec le serveur cible
#
function PING_HOST($server){
	
	if(!(test-connection -cn $server -count 2 -quiet )){
		
		write-log -log "Le serveur $server n`'est pas joignable" -Color red
        
		exit
	
	}
}


 
#
#Test le nombre de parametres 
#
 function USAGE($parameters){

    if($parameters -lt 3){
        
        Write-Host Error : arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `<START ou STOP ou STATUS`> `<Nom Base de donnnees> `< Type BDD`>`<Nom_serveur`>
        
        exit
    }

 }

 #
#Fonction qui verifie si le script existe sur le serveur distant 
#
function TEST_SCRIPT($server,$path_){
    
    #Si on ne renseigne pas le chemin complet
    if(!(split-path -Path $path_ -IsAbsolute)){
        write-log -log "Attention il est preferable de mettre le chemin complet du script : $path_" -color DarkYellow
        return $true
    }

    #Traitement sur le chemin, on transforme c:\path en c$\path
    $debut = (Split-Path -Path $path_ -Qualifier -ErrorAction Stop) -replace ':','$'

    $last_path = $path_

    #On enleve le c:
    $path_ = Split-Path  $path_  -NoQualifier

    #on forme le \path en c$\path
    $path_ = Join-Path $debut $path_

    #on forme le  \\server\c$\path
    $path_ = Join-Path "\\$server\" $path_

    #On teste si c'est un dossier
    $result = Test-Path $path_ -PathType container 

    if($result){
        
        Write-log -log "$last_path est un dossier" -color DarkYellow
    
        return $false
    }

    #On teste si c`'est un fichier
	$result = Test-Path $path_ -PathType Leaf

    if($result -eq $false){

        Write-log -log "Fichier $last_path n`'existe pas" -color red
        return $result
    }
    
    return $result

}




#
#retourne les bases de donnéees qui ne sont pas disabled
#
function FIND_AUTO($databases, $bdd){
 
    $results = @()

    #on selectionne les lignes commencant par SQL
    $filtered = $databases | Select-String -Pattern "^SQL"
    
    if($filtered.count -eq 0){
        write-log "La base de donnees $bdd n`'a pas ete retrouvee" -color red
        exit
    }
    
    write-log  "Avant filtrage" -console $console
    #on les rajoute à resultat
    $filtered | ForEach-Object {
        Write-log  -log $_ -console $console
        $results += $_

    }
    
    #on converti en array list pour faire remove ;)
    $AutoBDD = [System.collections.ArrayList]$results
    


    foreach($res in $results){

        $fields = ($res -replace '\s+', ' '  ) -split ' '       
          
        # on  ne prend que le 3eme champs à partir de la droite, l'etat
        $startMode = $fields[-3]

        if($startMode -eq "Disabled" -or  $startMode -eq "Auto"){
            #si disable on l'enleve
            if($startMode -eq "disabled"){

                $AutoBDD.remove($res)

            }

        } 
        else
        {
            #on prend le champ 4 au cas echant car NT utilisateur rajoute un espace
            $startMode = $fields[-4]

            #si disable on l'enleve
            if($startMode -eq "disabled"){
                $AutoBDD.remove($res)
            }
        }
    }
    return $AutoBDD

}


#
#Fonction qui execute le script sur le serveur distant
#
function REMOTE_INVOCATION($server,$command, $arguments){
    	
	if(TEST_SCRIPT -server $server -path_  $command -eq $true)
    {    
        

        Invoke-Expression  ' & $PSEXEC \\$server -nobanner -w c:\temp -c -f $BAT_Psexec $command `"$arguments`" '2>&1    
        Start-Sleep -Seconds 3   
		
	}
 }

#
#Vérifie si la base de données existe et marche 
#
function CHECK_DATABASE($database, $server, $desiredState){
     
    
     #Execution du script de gestion des bases de données
     REMOTE_INVOCATION -server $server -command $DATABASE_SCRIPT_PATH -arguments "status $database all" 
     
     if(Test-Path \\$server\c$\temp\out.txt){

        #gc \\$server\c$\temp\logger.txt

        $req = gc \\$server\c$\temp\out.txt

    }else{

        write-log "Erreur lors de l`'execution "
        #gc \\$server\c$\temp\logger.txt
        exit
    }
    

     #On nettoit le répertoire
     #del \\$server\c$\temp\ps.txt

     #write-log -log $req 
     #on recupére les databases qui sont en auto start
     $autoBDD = FIND_AUTO -databases $req -bdd $database
     

     Write-log 'Apres filtrage' -console $console 
     $autoBDD | ForEach-Object{

       
       write-log $_ -console $console

       #on remplace les tabulations par des espaces
       $fields = ($_ -replace '\s+', ' '  ) -split ' '
       
       #on prend l'avant dernier champ qui correspond en général au state de la bdd
       for($i = 0 ; $i -lt $fields.count ; $i++){
            
            switch($fields[$i]){
                
                "running"{
                
                    if($desiredState -eq "stopped"){
                        return $false
                        exit
                    }
                    return $true
                }
                "stopped"{
                    
                    if($desiredState -eq "running"){
                        return $false
                        exit
                    }
                    return $true
                }
            }       
        }       
     }     
     
}


#
#Lance une base de données
#
function START_DATABASE($database, $server){
    
    $state = check_database -database $database -server $server -desiredState "stopped"

    if($state[0] -eq $false){

        write-log "la base de donnees $database est deja en exécution" -color darkyellow
        exit
    }

    $command = "$DATABASE_SCRIPT_PATH start $database all"
    
    Write-log -log "Relance de la base de donnees $database sur le serveur $server" 

    #Execution du script de gestion des bases de données
    REMOTE_INVOCATION -server $server -command $DATABASE_SCRIPT_PATH -arguments "start $database all" 
    
    $req = gc \\$server\c$\temp\out.txt
    
    #On ne renvoit que les lignes de résumé
    $req   
    
}


#
#Arrête une base de données
#
function STOP_DATABASE($database, $server){

    $state = check_database -database $database -server $server -desiredState "running"

    if($state[0] -eq $false){

        write-log "la base de donnees $database est deja arretee" -color darkyellow
        exit
    }

    Write-log -log "Arret de la base de donnees $database sur le serveur $server" 

    #Execution du script de gestion des bases de données
    REMOTE_INVOCATION -server $server -command $DATABASE_SCRIPT_PATH -arguments "stop $database all" 
    
    $req = gc \\$server\c$\temp\out.txt
    
    #On ne renvoit que les lignes de résumé
    $req  
}

#
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\database")){

        new-item -ItemType directory -name logs\database | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\database\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}
 
#
#Fonction main
#
 function main-process($action, $database,$type, $server){

    write-log -log "################# $action de la base de données $database sur le serveur $server #################" -console $false

    switch ($action)
    {
        "START" {
            start_database -database $database -server $server
        }

        "STOP" {

            stop_database -database $database -server $server
        }

        "STATUS"{

            $res =  check_database -database $database -server $server -desiredState "Running"
            
            #write-host runnng : $res

            if(!$res.contains($false)){

        
                write-host running
                write-log -log "La base de donnees $database est en marche" -console $false

            }else{

                $res =  check_database -database $database -server $server -desiredState "Stopped"
                
                #write-host stopped : $res
                if(!$res.contains($false)){
                    
                    Write-Host stopped
                    write-log -log "La base de donnees $database est arrété" -console $false
                }else{
                    #write-host erreur : $res
                    write-host erreur
                }

            }
        }

        default {
            
            write-host "Cette action $action n`'est pas reconnue"
            usage -parameters 0
        }
    }
    
}

########################### MAIN #############################


#test le nombre de paramétres
USAGE -parameters $args.Count


$action = $args[0]
$database = $args[1]
$server = $args[-1]

#Vérifie la connectivité
PING_HOST -server $server

main-process -action $action -database $database -type $type -server $server


