﻿<###########################################################

    Author = Samba NDIAYE
    Description = this code is for the automation of 
    the start/stop procedure

############################################################>


$LOG_FILE = "CheckDisk.log"
$server
$willOutput=$false
$BAT_Psexec = 'script_invoker.bat'
$PSEXEC_OUTPUT = 'c$\temp\out.txt'

#permet de voir ou pas les logs quand on appel la commande

#
#Test la connection avec le serveur cible
#
function PING_HOST($server){
	
	if(!(test-connection -cn $server -count 2 -quiet )){
		
		write-log -log "Le serveur $server n`'est pas joignable" -color red
        
		exit
	
	}
}


 
#
#Test le nombre de parametres 
#
 function USAGE($parameters){

    if($parameters -lt 2){
        
        Write-Host Error : arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `[ lecteur`] `[ Nom_serveur`]
        
        exit
    }

 }

 
#Fonction qui verifie si le script existe sur le serveur distant 
#
function TEST_PATH($server,$path_){
    
    #Si on ne renseigne pas le chemin complet
    if(!(split-path -Path $path_ -IsAbsolute)){
        #write-log -log "Attention il est preferable de mettre le chemin complet du script : $path_" -color DarkYellow
        return $true
    }

    #Traitement sur le chemin, on transforme c:\path en c$\path
    $debut = (Split-Path -Path $path_ -Qualifier -ErrorAction Stop) -replace ':','$'

    $last_path = $path_

    #On enleve le c:
    $path_ = Split-Path  $path_  -NoQualifier

    #on forme le \path en c$\path
    $path_ = Join-Path $debut $path_

    #on forme le  \\server\c$\path
    $path_ = Join-Path "\\$server\" $path_

    #On teste si c'est un dossier
    $result = Test-Path $path_ -PathType container 

    if($result){
        
        Write-log -log "$last_path est un dossier" -color DarkYellow -console $willOutput
        return $true
        
    }

    #On teste si c`'est un fichier
	$result = Test-Path $path_ -PathType Leaf

    if($result -eq $false){

        Write-log -log "Fichier $last_path n`'existe pas" -color red -console $willOutput
        return $false
        
    }
    

}


 function testIf-Directory($directory){
    
    if(($directory -split '\\').Count -gt 1 ){
        Write-log -log "C'est un repertoire" -console $willOutput
        return $true
    }
    return $false
 }



#
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\checkDisk")){

        new-item -ItemType directory -name logs\checkDisk | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\CheckDisk\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}

#
#Cherche les disques sur un serveur distant
#
 
function find_disk($disks, $result){

    $disks_found = @()

    $notFound = @()

    
    $disks | ForEach-Object { 
        
        #on enleve les signes qui peuvent etre mis par l'utilisateur \ ou: ou /
        $disk = ($_ -replace '[:\\/]',"").ToUpper()

        if($res.contains($disk)){

            Write-log "$disk est present sur $server" -console $willOutput

            #on ajoute ce disque à ceux qui ont étaient retrouvés
            $disks_found = $disks_found + $disk

        }else{

            Write-log "$disk n'est pas present sur $server" -console $willOutput

            #on ajoute ce disque à ceux qui n'ont pas étaient retrouvés
            $notFound = $notFound + $disk
        }

    }

    if($notFound.Count -lt 1){

        Write-Host OK

    }else{
        
        Write-log "Disques du serveur $server : `t$result" -console $willOutput
        write-log "Trouvé(s) sur $server : `t`t$disks_found" -console $willOutput
        write-log "Non trouvé(s) sur $server :`t`t$notFound" -console $willOutput 
        
        write-host KO
        
    }

}
#
#Fonction main
#
 function main-process($server, $disks){

    $repertoire = $disks -join " "


    if(!(testIf-Directory -directory $repertoire )){

        Write-log -log "============ Recherche des disques $disks sur le serveur $server ============" -console $willOutput
    
        $res = (Get-WmiObject win32_LogicalDisk -cn $server).deviceID -join '' -replace ":"," "

    
        write-log -log "result  : $res" -console $willOutput 
    
        #Au cas ou l'utilisateur separe les disques par des virgules 
        $disks = ($disks -replace ","," ") -split " "


        find_disk -disks $disks -result $res
    }
    else
    {
        if(test_path -path_ $repertoire -server $server){
            Write-Host OK
        }
        else
        {
            Write-Host KO
        }
    }
    
       
}

 ########################### MAIN ################################

#test le nombre de paramétres
USAGE -parameters $args.Count

$server = $args[-1]
$disk = $args[0..($args.Count -2)] 

#Vérifie la connectivité
PING_HOST -server $server


#Lance l'action principale
main-process -disks $disk  -server $server 
