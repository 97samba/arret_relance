﻿<###########################################################

    Author = Samba NDIAYE
    Description = this code is for the automation of 
    the start/stop procedure of the ARES application (PARPRE)

############################################################>


$LOG_FILE = "process.log"
$VERSION = 1.4

#
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\process")){

        new-item -ItemType directory -name logs\process | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\process\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}

#
#Test la connection avec le serveur cible
#
function PING_HOST($server){
	
	if(!(test-connection -cn $server -count 1 -quiet )){
		
		write-log -log "Le serveur $server n`'est pas joignable" -Color red
        
		exit
	
	}
}


#
#Test le nombre de parametres 
#
 function USAGE($parameters){

    if($parameters -lt 3){
        
        Write-Host Error : arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `[ START ou STOP ou STATUS` ] `[ Nom_Process ] `[ Nom_serveur`]
        
        exit
    }

 }

#
#Vérifie si le service existe et marche 
#
function CHECK_PROCESS($processes, $server){
    
    foreach( $process in $processes){
        
	    $process = [System.IO.path]::GetFileNameWithoutExtension($process)

        $status =  (get-process -ComputerName $server -Name $process -ErrorAction SilentlyContinue).__NounName       
         
        

        if($status -ne $null)
        {
            write-log -log "Le processus $processes est en cours" -console $false
            return "running"
         
        }
        else
        {
            write-log -log "Le processus $processes n'est pas en cours d'execution" -console $false
            return "stopped"
        }
    }  

}

function STOP_PROCESS($ProcessName, $server){
    
    $ProcessName.getType()
    $obj = Get-WmiObject -Class Win32_Process -ComputerName $server -Filter "name='$ProcessName'"
    $obj.terminate()
    

}

#
#Fonction main
#
 function main-process($state, $process, $server){



    if($state -eq "start"){

        #start_process -service $service -server $server
    }

    if($state -eq "stop")
    {
        stop_process -ProcessName $process -server $server
    }

    if($state -eq "status")
    {
        
        check_process -process $process -server $server
    }
    
    if(($state -ne "stop") -and ($state -ne "start") -and ($state -ne "status"))
    {
        write-host `n$(get-date -Format 'hh:mm dd/MM/yyyy') : Èrreur sur l`'action : $state -ForegroundColor Red
        Write-Host `nUSAGE : $(Split-Path $PSCommandPath -Leaf) `<START ou STOP`> `<Nom_Service> `<Nom_serveur`>
    }
    
}

 ########################### MAIN ################################

#test le nombre de paramétres
USAGE -parameters $args.Count

$state = $args[0]
$process = $args[1..($args.count -2)]
$server = $args[-1]

#Vérifie la connectivité
PING_HOST -server $server

#Lance l'action principale
main-process -state $state -process $process -server $server





