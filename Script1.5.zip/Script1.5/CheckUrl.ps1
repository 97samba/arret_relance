﻿<###########################################################

    Author = Samba NDIAYE
    Description = this code is for the automation of 
    the start/stop procedure 
    
############################################################>


#fichier log
$LOG_FILE = "checkUrl.log"
$VERSION = 1.4

#
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\chechUrl")){

        new-item -ItemType directory -name logs\chechUrl | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\chechUrl\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}

#
#Test le nombre de parametres 
#
 function USAGE($parameters){

    if($parameters -ne 2){
        
        write-host "Vérifies si un lien est dans un état préciser(si un site est joignable)"

        Write-Host Error : arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `[ Url `] `[ UP ou DOWN ]
        
        exit
    }

 }

 function CHECK_URL($url){
    
    try
    {
        $req = Invoke-WebRequest -Uri $url
        
        $StatusCode = $req.StatusCode
    }
    catch
    {
        $StatusCode = $_.Exception.Response.StatusCode.value__
    }
    $StatusCode
    
    $web_state = 'running'

    #les bons codes errreurs sont entre 200 et 299
    if(($StatusCode -lt 200) -or ($statuscode -gt 299)){

        $web_state = 'stopped'

    }
    
    write-log -log "$url est $web_state" -console $false
    
    return $web_state    
}

function CHECK_CONTENT($url,$content){

    $content = (Invoke-WebRequest -Uri $url).content

    if($content.Length -eq 0){

        return "PAGE_BLANCHE"

    }else{
        
        return OK
    }
}

function main-process($url, $action,$content){

    switch ($action)
    {
        "CONTENT" {
            CHECK_CONTENT -url $url -content $content
        }

        "STATUS" {

            CHECK_URL -url $url
        }

        default {
            
            write-host "Cette action $action n`'est pas reconnue"
        }
    }
}
 ###########################MAIN##############################

#test le nombre de paramétres
USAGE -parameters $args.Count

$action = $args[0]

$url= $args[1]


main-process -action $action -url $url 
