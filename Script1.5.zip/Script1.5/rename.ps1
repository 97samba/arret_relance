﻿<###########################################################

    Author = Samba NDIAYE
    Description = Ce script sert à renommer des fichiers sur une serveur distant

############################################################>


$LOG_FILE = "rename.log"
$path
$newName
$server

#permet de voir ou pas les logs quand on appel la commande
$willOutput=$true
#
#Test la connection avec le serveur cible
#
function PING_HOST($server){
	
	if(!(test-connection -cn $server -count 2 -quiet )){
		
		write-log -log "Le serveur $server n`'est pas joignable" -color red
        
		exit
	
	}
}

 
#
#Test le nombre de parametres 
#
 function USAGE($parameters){

    if($parameters -lt 3){
        
        Write-Host Error : arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `[ Nom Fichier`] `[ nouveau Nom`] `[ Nom_serveur`]
        
        exit
    }

 }


 #
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\rename")){

        new-item -ItemType directory -name logs\rename | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\rename\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}


#
#Test l'extension du script à exécuter 
#      role :  précéder la commande de "powershell" si l'extension est .ps1
#
function GET_EXTENSION($file){
	
	if([System.IO.path]::GetExtension($file) -eq ".bat"){
		
		return ""
	}

	if([System.IO.path]::GetExtension($file) -eq ".ps1"){
		
		return "powershell"
	}
	else
    {
        
		return ""
	}
	 
	
}

#
#Fonction qui verifie si le script existe sur le serveur distant 
#
function TEST_SCRIPT($server,$path_){
    
    #Si on ne renseigne pas le chemin complet
    if(!(split-path -Path $path_ -IsAbsolute)){
        #write-log -log "Attention il est preferable de mettre le chemin complet du script : $path_" -color DarkYellow
        return $true
    }

    #Traitement sur le chemin, on transforme c:\path en c$\path
    $debut = (Split-Path -Path $path_ -Qualifier -ErrorAction Stop) -replace ':','$'

    $last_path = $path_

    #On enleve le c:
    $path_ = Split-Path  $path_  -NoQualifier

    #on forme le \path en c$\path
    $path_ = Join-Path $debut $path_

    #on forme le  \\server\c$\path
    $path_ = Join-Path "\\$server\" $path_

    #On teste si c'est un dossier
    $result = Test-Path $path_ -PathType container 

    if($result){
        
        Write-log -log "$last_path est un dossier" -color DarkYellow
        exit
        
    }

    #On teste si c`'est un fichier
	$result = Test-Path $path_ -PathType Leaf

    if($result -eq $false){

        Write-log -log "Fichier $last_path n`'existe pas" -color red
        exit
        
    }
    
    return $result

}

function rename_file($_path, $_server ){

    #On forme le C$
    $qualifier = (Split-Path -Path $_path -Qualifier) -replace ":", "$"

    #Le chemin sans le qualifier
    $noqualifier = Split-Path -Path $_path -NoQualifier

    #Le chemin distant
    $remotePath = Join-Path "\\$server\$qualifier" $noqualifier

    #renommage
    Rename-Item -Path $remotePath -NewName $newName

    #le nouveau fichier
    $newFile = Join-Path (Split-Path -Path $remotePath -Parent) $newName
    
    #test si tout s'est bien passé
    if(Test-Path -Path $newFile ){
        
        Write-log  -log "$_path renomme en $newName"

    }else{

        write-log "Erreur lors du renommage sur le serveur $_server"
    }
    

}

 
#
#Fonction main
#
 function main-process($_server, $_path, $_newName){

    if( TEST_SCRIPT -server $_server -path_ $_path){

        write-log -log "Renommage du fichier $_path en $_newName sur le serveur $_serveur"

        rename_file -_path $_path -_server $_server

    
    }else{

        write-log -log "Erreur lors de l'execution"
    }
    
    
	
}

 ########################### MAIN ################################

#test le nombre de paramétres
USAGE -parameters $args.Count

$server = $args[-1]

$newName = $args[-2]

#Si le chemin comporte des espaces ou pas
if($args.Count -eq 3){
    
    $path = $args[0]

}else{

    #si le fichier comporte des espaces
    $path = $args[0..($args.count - 3)] -join " "        
}



#Vérifie la connectivité
PING_HOST -server $server


#Lance l'action principale
main-process -_path $path -_newName $newName -_server $server 
