﻿<###########################################################

    Author = Samba NDIAYE
    Description = this code is for the automation of 
    the start/stop procedure
    
############################################################>


    


$LOG_FILE = "pool_IIS.log"
$PSEXEC = '.\PsExec.exe'
$VERSION = 1.4
$willOutput = $true
$BAT_Psexec = 'script_invoker.bat'
#
#Test la connection avec le serveur cible
#
function PING_HOST($server){
	
	if(!(test-connection -cn $server -count 2 -quiet )){
		
		write-host Le serveur $server n`'est pas joignable -foregroundColor red
        
		exit
	
	}
}

#
#Test le nombre de parametres 
#
 function USAGE($parameters){

    if($parameters -lt 3){
        
        Write-Host Error : arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `-action` [ START ou STOP ou STATUS` ] `-element `[ Nom_element ] `-type`[ Type_element ] `serveur `[ Nom_serveur`]
        
        exit
    }
    
 }

 #
#Fonction qui initialise (test les prerequis dans notre cas PSEXEC.exe et module web administration) 
#
function INIT(){

	if(!(Get-Command $PSEXEC)){
	
		write-log -log "Psexec introuvable" -color red

		exit
	}

}

<######### POOL ########>

#
#Vérifie si le pool existe et marche 
#
function CHECK_POOL($pool, $server){

    #recupere l`'état
    
    $command = "(Get-WebAppPoolState -name $pool).value"

    Invoke-Expression  ' & $PSEXEC \\$server -nobanner -w c:\temp -c $BAT_Psexec $command '2>&1            
   
    #Le script psexec ecrit dans un fichier ps.txt, on le récupere
    $status = gc \\$server\c$\temp\out.txt


    if($status -eq $null)
    {

        Write-log -log "Le pool $pool n`'existe pas sur le serveur $server"
        exit
         
    }

    if($status -eq "stopped")
    {
        Write-log -log "Le pool $pool est arrété" -console $false
        return $false
    }
    
    if($status -eq "running")
    {
        Write-log -log "Le pool $pool est en cours d'execution" -console $false
        return $true
    }

}

#
#Lance un pool IIS
#
function START_POOL($pool, $server){

    #Si le pool est deja en cours
    if(CHECK_POOL -pool $pool -server $server)
    {
        
        Write-log -log "Le pool $pool est deja en cours d`'execution sur le serveur $server" -color Yellow
        
    }
    else
    {
        
        write-log -log "Démarrage du pool $pool sur le serveur $server" 
        
        #Démarrage du pool
        Invoke-Expression " & $PSEXEC \\$server -nobanner powershell Start-WebAppPool -name $pool " 2>&1
		              
        #Vérifie si le pool est bien démarré
        if(CHECK_POOL -pool $pool -server $server)
        {
            
            write-log -log "Le pool $pool est bien démarré sur le serveur $server" -Color Green
      
        }
        else
        {            
            write-log -log "Èrreur lors de la relance pool $pool sur le serveur $server" -color red
        }
    }
}


#
#Arrête un pool
#
function STOP_POOL($pool, $server){

    
    if(CHECK_POOL -pool $pool -server $server){
        
        write-log -log "Arrêt du pool $pool sur le serveur $server" -console $true

        #Arrêt du pool
        Invoke-Expression " & $PSEXEC \\$server -nobanner powershell Stop-WebAppPool -name $pool " 2>&1
		

        #Verifie que le pool est bien arrété 
        if(!(CHECK_POOL -pool $pool -server $server))
        {
            
            write-log -log "Le pool $pool est bien arrété sur le serveur $server" -color Green
      
        }else{
            
            write-log -log "Èrreur lors de l`'arrêt pool $pool sur le serveur $server" -color red

        }

    }else{
        
         write-log -log "Le pool $pool est deja arrété sur le serveur $server" -color Yellow -console $true
    }
    

}

<######### SITE ########>

#
#Arrête un site
#
function STOP_SITE($site, $server){

    
    if(CHECK_SITE -site $site -server $server){
        
        write-log -log "Arrêt du site $site sur le serveur $server" -console $true

        #Arrêt du pool
        Invoke-Expression " & $PSEXEC \\$server -nobanner powershell Stop-IISSite -name $site " 2>&1
		

        #Verifie que le pool est bien arrété 
        if(!(CHECK_POOL -site $site -server $server))
        {
            
            write-log -log "Le site $site est bien arrété sur le serveur $server" -color Green
      
        }else{
            
            write-log -log "Èrreur lors de l`'arrêt site $site sur le serveur $server" -color red

        }

    }else{
        
         write-log -log "Le site $site est deja arrété sur le serveur $server" -color Yellow -console $true
    }
    

}

#
#Lance un site
#
function START_SITE($site, $server){

    #Si le pool est deja en cours
    if(CHECK_SITE -site $site -server $server)
    {
        
        Write-log -log "Le site $site est deja en cours d`'execution sur le serveur $server" -color Yellow
        
    }
    else
    {
        
        write-log -log "Démarrage du site $site sur le serveur $server" 
        
        #Démarrage du pool
        Invoke-Expression " & $PSEXEC \\$server -nobanner powershell Start-IISSite -name $site " 2>&1
		              
        #Vérifie si le pool est bien démarré
        if(CHECK_POOL -site $site -server $server)
        {
            
            write-log -log "Le site $site est bien démarré sur le serveur $server" -Color Green
      
        }
        else
        {            
            write-log -log "Èrreur lors de la relance site $site sur le serveur $server" -color red
        }
    }
}

#
#Vérifie si le site existe et marche 
#
function CHECK_SITE($site, $server){

    #recupere l`'état
    
    $command = "(Get-WebsiteState -name $site).value"

    Invoke-Expression  ' & $PSEXEC \\$server -nobanner -w c:\temp -c $BAT_Psexec $command'2>&1            
   
    #Le script psexec ecrit dans un fichier ps.txt, on le récupere
    $status = gc \\$server\c$\temp\ps.txt

    if($status -eq $null)
    {

        Write-log -log "Le site $site n`'existe pas"
        exit
         
    }

    if($status -eq "stopped")
    {
        Write-log -log "Le site $site est arrété" -console $willOutput
        return $false
    }
    
    if($status -eq "running")
    {
        Write-log -log "Le site $site est en cours d'execution" -console $willOutput
        return $true
    }
    write-log -log $status

}

#
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\pool_iis")){

        new-item -ItemType directory -name logs\pool_iis | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\pool_iis\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}
 
#
#Fonction main
#
 function main-process($state, $element,$type, $server){


    switch ($state)
    {
        "START" {
            start_pool -pool $element -server $server
        }

        "STOP" {

            stop_pool -pool $element -server $server 
        }

        "STATUS" {

            $res =  CHECK_POOL -pool $element -server $server
      
            if($res){
        
                write-host running

            }
            else
            {

                write-host stopped
            }
        }

        default {
            
            write-host "Cette action $action n`'est pas reconnue"
            usage -parameters 0
        }
    }
    
}

 ########################### MAIN ################################


#test le nombre de paramétres
USAGE -parameters $args.Count

$state = $args[0]

#peut etre un pool iis ou un website
$element=$args[1..($args.count - 3)] -join " "

#Type de l'element ne prend que deux valeurs Pool / Site
$type = $args[-2]

$server = $args[-1]

#Vérifie la connectivité
PING_HOST -server $server

#on initialise
INIT 


#Lance l'action principale
main-process -state $state -element $element -type $type -server $server