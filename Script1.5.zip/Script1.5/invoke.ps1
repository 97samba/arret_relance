﻿<###########################################################

    Author = Samba NDIAYE
    Description = this code is for the automation of 
    the start/stop procedure

############################################################>


$PSEXEC = '.\PsExec.exe'
$LOG_FILE = "invoke.log"
$path
$server
$willOutput=$true

$BAT_Psexec = '.\script_invoker.bat'

$PSEXEC_OUTPUT = 'c$\temp\out.txt'

#permet de voir ou pas les logs quand on appel la commande

#
#Test la connection avec le serveur cible
#
function PING_HOST($server){
	
	if(!(test-connection -cn $server -count 2 -quiet )){
		
		write-log -log "Le serveur $server n`'est pas joignable" -color red
        
		exit
	
	}
}

#
#Fonction qui initialise (test les prerequis dans notre cas PSEXEC.exe) 
#
function INIT(){

	if(!(Get-Command $PSEXEC)){
	
		write-log -log "Psexec introuvable" -color red
        $willOutput = $true
		exit
	}


}

 
#
#Test le nombre de parametres 
#
 function USAGE($parameters){

    if($parameters -lt 2){
        
        Write-Host Error : arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `[ Commande`] `[ Nom_serveur`]
        
        exit
    }

 }

#
#Test l'extension du script à exécuter 
#      role :  précéder la commande de "powershell" si l'extension est .ps1
#
function GET_EXTENSION($file){
	
	if([System.IO.path]::GetExtension($file) -eq ".bat"){
		
		return ""
	}

	if([System.IO.path]::GetExtension($file) -eq ".ps1"){
		
		return "powershell"
	}
	else
    {
        
		return ""
	}
	 
	
}

#
#Fonction qui verifie si le script existe sur le serveur distant 
#
function TEST_SCRIPT($server,$path_){
    
    #Si on ne renseigne pas le chemin complet
    if(!(split-path -Path $path_ -IsAbsolute)){
        #write-log -log "Attention il est preferable de mettre le chemin complet du script : $path_" -color DarkYellow
        return $true
    }

    #Traitement sur le chemin, on transforme c:\path en c$\path
    $debut = (Split-Path -Path $path_ -Qualifier -ErrorAction Stop) -replace ':','$'

    $last_path = $path_

    #On enleve le c:
    $path_ = Split-Path  $path_  -NoQualifier

    #on forme le \path en c$\path
    $path_ = Join-Path $debut $path_

    #on forme le  \\server\c$\path
    $path_ = Join-Path "\\$server\" $path_

    #On teste si c'est un dossier
    $result = Test-Path $path_ -PathType container 

    if($result){
        
        Write-log -log "$last_path est un dossier" -color DarkYellow
        exit
        
    }

    #On teste si c`'est un fichier
	$result = Test-Path $path_ -PathType Leaf

    if($result -eq $false){

        Write-log -log "Fichier $last_path n`'existe pas" -color red
        exit
        
    }
    
    return $result

}

#
#Fonction qui execute le script sur le serveur distant
#
function REMOTE_INVOCATION($server,$command, $arguments){
    
	if(TEST_SCRIPT -server $server -path_  $command -eq $true)
    {
		
        Write-log -log "Execution du script : $command $arguments sur la machine $server" 
		
        Invoke-Expression  ' & $PSEXEC \\$server -nobanner -c -f -w c:\temp  $BAT_Psexec $command `"$arguments`" '2>&1
        
        Start-Sleep -Seconds 3    
 
	}
 }

#
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\invoke")){

        new-item -ItemType directory -name logs\invoke | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\invoke\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}

 
#
#Fonction main
#
 function main-process($server, $path){
    
   
    
    #decoupe de maniere à avoir 2 champs et prends le premier element

    if($path.count -gt 1){

        #On vérifie si le chemin n'a pas des espaces
        #exemple c:\program files
        if(($path[1] -split "\\").count -gt 1){

            $command = $path[0..1] -join " "

            $arguments = $path[2..($path.count - 1)] -join " "
        }
        else
        {
            
            $command = $path[0]
            $arguments = $path[1..($path.count - 1)] -join " "
        }

      
    }
    else
    {
    $command = $path[0]
    }
    
    
    $res = REMOTE_INVOCATION -server $server -command $command -arguments $arguments
    
    if(Test-Path \\$server\$PSEXEC_OUTPUT){

        #gc \\$server\c$\temp\logger.txt
        gc \\$server\c$\temp\out.txt

    }else{
        Test-Path \\$server\$PSEXEC_OUTPUT
        write-log "Erreur lors de l`'execution, $server\$PSEXEC_OUTPUT introuvable"
        #gc \\$server\c$\temp\logger.txt
        exit
    }
    
    

    $res
    
    #On néttoie le répertoire
    #del \\$server\c$\temp\out.txt
    
	
}

 ########################### MAIN ################################

#test le nombre de paramétres
USAGE -parameters $args.Count

$server = $args[-1]
$path = $args[0..($args.Count -2)]

#Vérifie la connectivité
PING_HOST -server $server

#Vérifier si psexec existe
INIT 

#Lance l'action principale
main-process -path $path  -server $server 
