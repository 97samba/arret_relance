﻿<###########################################################

    Author = Samba NDIAYE
    Description = this code is for the automation of 
    the start/stop procedure
    
############################################################>



$LOG_FILE = "checkLog.log"
$VERSION = 1.4
#
#Test la connection avec le serveur cible
#
function PING_HOST($server){
	
	if(!(test-connection -cn $server -count 2 -quiet )){
		
		write-log -log "Le serveur $server n`'est pas joignable" -color red
        
		exit
	
	}
}

#
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\checkLog")){

        new-item -ItemType directory -name logs\checkLog | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\checkLog\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}

#
#Test le nombre de parametres 
#
 function USAGE($parameters){

    if($parameters -lt 3){
        
        write-host Cherche un log ,entre guillemets, dans un fichier se trouvant dans un serveur distant.

        Write-Host Error : arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `[ `" log`" `] `[ Path ] `[ serveur ]
        
        exit
    }

 }

 
#Fonction qui verifie si le script existe sur le serveur distant 
#
function TEST_SCRIPT($server,$path){

    #Si on ne renseigne pas le chemin complet
    if(!(split-path -Path $path -IsAbsolute)){
        #write-log -log "Attention il est preferable de mettre le chemin complet du script : $path_" -color DarkYellow
        return $true
    }

    #Traitement sur le chemin, on transforme c:\path en \\server\c$\path
    $debut = (Split-Path -Path $path -Qualifier) -replace ':','$'

    $last_path = $path

    #On enleve le c:
    $path = Split-Path  $path  -NoQualifier

    #on forme le \path en c$\path
    $path = Join-Path $debut $path

    #on forme le  \\server\c$\path
    $path = Join-Path "\\$server\" $path

    #On teste si c'est un dossier
    $result = Test-Path $path -PathType container 

    if($result){
        
        Write-log -log "$last_path est un dossier" -Color DarkYellow
        
        exit
        #return $false
    }

    #On teste si c`'est un fichier
	$result = Test-Path $path -PathType Leaf

    if($result -eq $false){

        Write-log -log "Le fichier $last_path n`'existe pas" -color red
        exit
        #return $result
    }
    
    return $path

}



 function SEARCH(){
    
    #on recupére le script distant 
    $remote_path = TEST_SCRIPT -server $server -path $path

    if($remote_path){

        $result = @()
        
        #on cherche toutes les ligness contenant le log spécifié        
        select-string -Path $remote_path -Pattern $log  | ForEach-Object{

            $result += $_.Matches.Value

            #Write-Host $_
          
        }
        if($result.count -gt 0){
            
            write-log -log "Le pattern $log a été retrouve dans le fichier $path sur le serveur $server" -console $false
            write-host "ok"

            exit
        }
        write-log -log "Le pattern $log n'a pas été retrouve dans le fichier $path" -console $false

        write-host "ko"
    }

 }




 ############################# Main ###########################

#test le nombre de paramétres
USAGE -parameters $args.Count

#les logs peuvent avoir des espaces donc compté comme plusieurs arguments
$log = ($args[0..($args.count -3)] -join " ")

$path = $args[-2]

$server = $args[-1]


#Vérifie la connectivité
PING_HOST -server $server

SEARCH  $log $path $server