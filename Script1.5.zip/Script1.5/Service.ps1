﻿<###########################################################

    Author = Samba NDIAYE
    Description = this code is for the automation of 
    the start/stop procedure
    
############################################################>

#Parametres
<#
Param (
    $state,
    $service,
    $server
)
#>

$LOG_FILE = "services.log"
$VERSION = 1.4

$state=""
$service=""
$server=""

#
#Test la connection avec le serveur cible
#
function PING_HOST($server){
	
	if(!(test-connection -cn $server -count 2 -quiet )){
		
		write-host Le serveur $server n`'est pas joignable -foregroundColor red
        
		exit
	
	}
}

#
#Test le nombre de parametres 
#
 function USAGE($parameters){
    
    if($parameters.count -lt 3){
        
        Write-Host Error ou arguments manquant`(s`) -ForegroundColor DarkYellow

        Write-Host `nUSAGE : $(split-path $PSCommandPath -Leaf) `[ START ou STOP ou STATUS` ] `[ Nom_Service ] `[ Nom_serveur`]
        
        exit
    }

 }

#
#Vérifie si le service existe et marche 
#
function CHECK_SERVICE($service, $server){

    #recupere l`'état
    $status = Get-Service  $service -ComputerName $server -ErrorAction SilentlyContinue | Select-Object -ExpandProperty status -ErrorAction SilentlyContinue
    
    if($status -eq $null)
    {

        Write-log -log "Le service $service n`'existe pas"
        exit
         
    }

    if($status -eq "stopped")
    {
        Write-log -log "Le service $service est arrete" -console $false
        return $false
    }
    
    if($status -eq "running")
    {
        Write-log -log "Le service $service est en cours" -console $false
        return $true
    }
    

}

#
#Lance un service
#
function START_SERVICE($service, $server){

    #Si le service est deja en cours
    if(CHECK_SERVICE -service $service -server $server)
    {
        
        Write-log -log "Le service $service est deja en cours d`'execution sur le serveur $server" -color Yellow
        

    }
    else
    {
        
        write-log -log "Demarrage du service $service sur le serveur $server" 
        
        #on recupere l`'objet service distant 
        $object = Get-Service -ComputerName $server -Name $service
        
        #on execute la relance sur sa representation en local
        Start-Service -InputObject $object -ErrorAction SilentlyContinue
        
        #Vérifie si le service est bien démarré
        if(CHECK_SERVICE -service $service -server $server)
        {
            
            write-log -log "Le service $service est bien demarre sur le serveur $server" -Color Green
      
        }
        else
        {
            
            write-log -log "Erreur lors de la relance service $service sur le serveur $server" -color red

        }
    }
}


#
#Arrête un service
#
function STOP_SERVICE($service, $server){

    
    if(CHECK_SERVICE -service $service -server $server){
        
        write-log -log "Arrêt du service $service sur le serveur $server" -console $true

        #recupere l`'object service distant et le represente en local
        $object = Get-Service -ComputerName $server -Name $service
        
        #effectue l'arrêt sur l'objet en local
        stop-Service -InputObject $object -ErrorAction SilentlyContinue 

        #Verifie que le service est bien arrété 
        if(!(CHECK_SERVICE -service $service -server $server))
        {
            
            write-log -log "Le service $service est bien arrété sur le serveur $server" -color Green
      
        }else{
            
            write-log -log "Èrreur lors de l`'arrêt service $service sur le serveur $server" -color red

        }

    }else{
        
         write-log -log "Le service $service est deja arrété sur le serveur $server" -color Yellow -console $true
    }
    

}

#
#Ecris des logs
#
function write-log(){

    param (
        $log,
        $color = "white",
        $console = $true
    )

    $log = "`n$(get-date -Format 'hh:mm dd/MM/yyyy')  : $log"

    #si le dossier log n'existe pas on le cree
    if(!(Test-Path -Path ".\logs\service")){

        new-item -ItemType directory -name logs\service | Out-Null
        
    }
    $date = (Get-Date -Format "dd-MM-yyyy-")
    #on ecrit dans le fichier log
    Add-Content -Value $log -Path .\logs\service\$date$LOG_FILE 

    if(!$console) {return}

   
    #On ecrit dans la sortie standard
    write-host $log -ForegroundColor $color    
}
 
#
#Fonction main
#
 function main-process($state, $service, $server){

    
    
    switch ($state)
    {
        "START" {
            start_service -service $service -server $server
        }

        "STOP" {

            stop_service -service $service -server $server
        }

        "STATUS" {

            $res =  CHECK_SERVICE -service $service -server $server
      
            if($res){
        
            write-host running

            }else{

            write-host stopped
            
            }
        }

        default {
            
            write-host "Cette action $action n`'est pas reconnue"
            usage -parameters 0
        }
    }
}

 ########################### MAIN ################################


#test le nombre de paramétres
USAGE -parameters $args

#Le serveur est le dernier argument
$server = $args[-1]

#state est le premier argument et le nom du service est le reste(entre 1 et la taille -2)
$state=$args[0]

$service = $args[1..($args.count - 2)] -join " "

#Vérifie la connectivité
PING_HOST -server $server

#Lance l'action principale
main-process -state $state -service $service -server $server